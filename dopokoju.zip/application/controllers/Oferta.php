<?php


class Oferta extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('oferta_model');
	}

	public function index()
	{
		$data['oferta']=$this->oferta_model->getOferta();
		$this->load->view('oferta',$data);

	}

}
