<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html" ; charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Aplikacja do zamawiania jedzenia na terenie Politechniki Rzeszowskiej">
	<title>Do Pokoju</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../../user_guide/_static/css/bootstrap.min.css"/>
	<link rel="icon" type="image/gif" href="<?php echo base_url(); ?>/favicon.gif"/>
</head>
<body style="background-color: #231f20">
<div id="page">
	<nav class="navbar navbar-expand-lg navbar-light fixed-top"
		 style="background-color: #231f20; border-bottom-style: solid; border-bottom-color: #ceaa63;">
		<div class="d-flex flex-grow-1">
			<span class="w-100 d-lg-none d-block"><!-- hidden spacer to center brand on mobile --></span>
			<a class="navbar-brand d-none d-lg-inline-block pl-5" href="<?php echo base_url();?>" style="color:#ceaa63">
				<h2>Do Pokoju</h2>
			</a>
			<a class="navbar-brand-two mx-auto d-lg-none d-inline-block" href="<?php echo base_url();?>" style="color:#ceaa63">
				<h2>Do&nbsp;Pokoju</h2>
			</a>
			<div class="w-100 text-right">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#myNavbar">
					<span class="navbar-toggler-icon"></span>
				</button>
			</div>
		</div>
		<div class="collapse navbar-collapse flex-grow-1 text-right" id="myNavbar">
			<ul class="navbar-nav ml-auto flex-nowrap">
				<li class="nav-item">
					<a href="<?php echo base_url('oferta/');?>" class="nav-link m-2 menu-item nav-active">
						<button type="button" class="btn btn-dark" role="button" style="color:#ceaa63" aria-pressed="true"><i class="fas fa-utensils pr-1"></i> Oferta</button>
					</a>
				</li>
				<li class="nav-item">
					<a href="<?php echo base_url('user/login');?>" class="nav-link m-2 menu-item">
						<button type="button" class="btn btn-dark" role="button" style="color:#ceaa63"><i class="fas fa-user pr-1"></i>Logowanie</button>
					</a>
				</li>
				<li class="nav-item">
					<a href="<?php echo base_url('user/register');?>" class="nav-link m-2 menu-item">
						<button type="button" class="btn btn-dark" role="button" style="color:#ceaa63"><i class="fas fa-user-plus pr-1"></i>Rejestracja</button>
					</a>
				</li>
				<li class="nav-item">
					<a href="<?php echo base_url('info');?>" class="nav-link m-2 menu-item">
						<button type="button" class="btn btn-dark" role="button" style="color:#ceaa63"><i class="fas fa-info pr-1"></i>Informacje</button>
					</a>
				</li>
			</ul>
		</div>
	</nav>
	<div id="welcome_bar" class="container-fluid rounded-lg pt-4 pb-3 mb-5" style="background-color: #2f2f2f">
		<p class="text-center" style="color:#ceaa63">Mmm głodny? Kebsa? ZAMAWIAJ TYPIE!!!</p>
	</div>
	<!---<div id="content" class="container-fluid" style="background-color: #231f20; color: #ceaa63;">-->
			<?php foreach($oferta as $item){?>
				<div class="d-inline-block m-5" style="color:#ceaa63">

					<h4 class="mr-2"><?php echo $item->nazwa; ?></h4>
					<p><?php echo $item->cena; ?></p>
					<button class="btn btn-dark" type="button" role="button">Zamów</button>

				</div>
			<?php } ?>
	<!--</div>-->
	<footer class="mt-5 p-3" style="border-top-style: solid; border-top-color: #ceaa63;color:#ceaa63;">
			<p class="text-center">Do Pokoju &copy; 2020</p>
	</footer>
</div>
<!-- asd -->
<!-- Bootstrap, jQuery, Popper, FontAwesome JS -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/70ad159df0.js" crossorigin="anonymous"></script>
<script>
	$('[data-toggle="popover"]').popover();
</script>
</body>
</html>
